import time
from selenium.webdriver import ActionChains
from selenium import webdriver
driver = webdriver.Chrome()
driver.get('https://hrmstest.ovivas.cn/#/PayrollList')
time.sleep(2)
driver.find_element_by_class_name("el-input__inner").send_keys("sg1112")
driver.find_element_by_xpath('//*[@type="password"]').send_keys('111111a')
driver.find_element_by_xpath('//*[@id="loginBtn"]').click()   #点击登录
time.sleep(3)
driver.maximize_window()  #设置页面窗口最大
time.sleep(2)
js ="window.open('https://www.baidu.com/','_blank')"   #打开第二个浏览器窗口
driver.execute_script(js.format())
time.sleep(2)
windows=driver.window_handles  #获取所有页面窗口句柄
driver.switch_to.window(windows[0])   #切换第一个句柄窗口
time.sleep(2)
driver.find_element_by_xpath('//*[@type="button"]/i').click()
driver.switch_to.window(windows[1])   #切换到第二个句柄窗口
time.sleep(3)
driver.find_element_by_xpath('//*[@id="kw"]').send_keys('游承燕')
time.sleep(2)
driver.find_element_by_xpath('//*[@value="百度一下"]').click()
time.sleep(5)
title = driver.title       #获取当前浏览器title
url = driver.current_url   #获取当前浏览器url
print(url)
print(title)
driver.back()   #浏览器后退
time.sleep(2)
title = driver.title
print(title)
driver.forward()  #浏览器前进
time.sleep(2)
driver.close()    #关闭浏览器当前标签窗口
# driver.quit()   #关闭浏览器所有窗口（整个浏览器）

import os
import unittest
import uuid

from selenium import webdriver
import time
from selenium.webdriver import ActionChains
from selenium.webdriver.common.keys import Keys
import HTMLTestRunner
from public.hrms_mylogin import MyLogin
import runner

PictersFile = 'D:/test/tt'


# def screenshot_as_file(driver: webdriver,types:bool=True):
#     endtime = time.strftime('%Y-%m-%d-%H-%M-%S', time.localtime())
#     mainpath = os.path.abspath(PictersFile)
#     error = os.path.join(mainpath, 'error')
#     info = os.path.join(mainpath, 'info')
#     if not os.path.exists(error):
#         os.mkdir(error)
#     if not os.path.exists(info):
#         os.mkdir(info)
#     path=os.path.join(info, endtime + ".png") if types else os.path.join(error, endtime + ".png")
#     driver.get_screenshot_as_file(path)
#     return path



class zuzhi(unittest.TestCase):

    def setUp(self) -> None:
        self.driver = webdriver.Chrome()
        self.driver.maximize_window()
        startime = time.strftime('%Y-%m-%d-%H-%M-%S', time.localtime())
        print('startime:',startime)

    def tearDown(self) -> None:
        endtime = time.strftime('%Y-%m-%d-%H-%M-%S',time.localtime())
        path=os.path.join(os.path.abspath(PictersFile),endtime+".png")
        self.driver.get_screenshot_as_file(path)
        # screenshot_as_file(self.driver,types=False)
        # screenshot_as_file(self.driver)

        self.driver.quit()

    def test_open_zuzhi(self):
        '进入员工管理下拉框下组织架构'
        MyLogin(self.driver).login()

        ele = self.driver.find_element_by_xpath('//*[@id="EmployeesMenu2"]/div')  #
        ActionChains(self.driver).move_to_element(ele).perform()  # 将鼠标定位到员工管理
        time.sleep(2)
        self.driver.find_element_by_xpath('//*[@x-placement="bottom-start"]/ul/li').click()  # 获取员工管理下拉框下组织架构并点击
        print(self.driver.title)
        print(self.driver.current_url)
        time.sleep(3)
        self.assertEqual('HRMS',self.driver.title)  #进入组织架构后，断言判断页面title是否符合预期’HRMS'，从而判断是否进入组织架构页

    #
    # def test_zuzhi_01(self):
    #     '进入员工管理下的组织架构，并引导滚动条下拉到指定元素move_to_element'
    #     MyLogin(self.driver).login()
    #     ele = self.driver.find_element_by_xpath('//*[@id="EmployeesMenu2"]/div')  #
    #     ActionChains(self.driver).move_to_element(ele).perform()      #将鼠标定位到员工管理
    #     time.sleep(2)
    #     self.driver.find_element_by_xpath('//*[@x-placement="bottom-start"]/ul/li').click()   #获取员工管理下拉框下组织架构并点击
    #     print(self.driver.title)
    #     print(self.driver.current_url)
    #     time.sleep(3)
    #     ele_01 = self.driver.find_element_by_xpath('//*[@id="TabEmployeesList"]/div[3]/table/tbody/tr[73]/td[1]/div/div')
    #     ActionChains(self.driver).move_to_element(ele_01).perform()
    #     # target = self.driver.find_element_by_xpath('//*[@id="TabEmployeesList"]/div[3]/table/tbody/tr[73]/td[1]/div/div')
    #     # self.driver.execute_script("arguments[0].scrollIntoView();", target)
    #     # js = "var q=document.documentElement.scrollTop=10000"
    #     # self.driver.execute_script(js)
    #     time.sleep(3)
    #     ele_02 = self.driver.find_element_by_xpath('//*[@id="TabEmployeesList"]/div[3]/table/tbody/tr[68]/td[3]/div').text
    #     print(ele_02)
    #     self.assertEqual('ccece015',ele_02)  #断言判断滚动条下拉页面后是否出现符合预期的元素
    #     self.assertTrue(self.driver.find_element_by_xpath('//*[@id="TabEmployeesList"]/div[3]/table/tbody/tr[68]/td[3]/div').is_displayed())
    #     self.assertIn('15',ele_02)
    #     time.sleep(2)
    # def test_zuzhi_02(self):
    #     'ActionChains，拖动鼠标从某个元素到指定元素drag_and_drop(开始元素，目标元素)'
    #     MyLogin(self.driver).login()
    #     ele = self.driver.find_element_by_xpath('//*[@id="EmployeesMenu2"]/div')  #
    #     ActionChains(self.driver).move_to_element(ele).perform()  # 将鼠标定位到员工管理
    #     time.sleep(2)
    #     self.driver.find_element_by_xpath('//*[@x-placement="bottom-start"]/ul/li').click()  # 获取员工管理下拉框下组织架构并点击
    #     print(self.driver.title)
    #     print(self.driver.current_url)
    #     time.sleep(3)
    #     ele_01 = self.driver.find_element_by_xpath('//*[@placeholder="搜索员工名字/工号"]')
    #     ele_02 = self.driver.find_element_by_xpath('//*[@placeholder="请选择岗位级别"]')
    #     ActionChains(self.driver).drag_and_drop(ele_01,ele_02)
    #     time.sleep(2)
    #     self.assertEqual('请选择岗位级别',ele_02.get_attribute('placeholder'))   #获取元素属性值get_attribute('元素')
    # def test_zuzhi_03(self):
    #     'Keys，键盘事件，send_keys(Keys.CONTROL,"C")'
    #     MyLogin(self.driver).login()
    #     ele = self.driver.find_element_by_xpath('//*[@id="EmployeesMenu2"]/div')  #
    #     ActionChains(self.driver).move_to_element(ele).perform()  # 将鼠标定位到员工管理
    #     time.sleep(2)
    #     self.driver.find_element_by_xpath('//*[@x-placement="bottom-start"]/ul/li').click()  # 获取员工管理下拉框下组织架构并点击
    #     time.sleep(2)
    #     self.driver.find_element_by_xpath('//*[@placeholder="搜索员工名字/工号"]').send_keys('sg1115')
    #     self.driver.find_element_by_xpath('//*[@placeholder="搜索员工名字/工号"]').send_keys((Keys.CONTROL,'A'))
    #     time.sleep(2)
    #     self.driver.find_element_by_xpath('//*[@placeholder="搜索员工名字/工号"]').send_keys((Keys.CONTROL, 'x'))
    #     time.sleep(2)
    #     self.driver.find_element_by_xpath('//*[@placeholder="搜索员工名字/工号"]').send_keys((Keys.CONTROL, 'c'))
    #     time.sleep(2)
    #     a = self.driver.find_element_by_xpath('//*[@placeholder="搜索员工名字/工号"]').location
    #     print(a)
    #     print(a['x'],a['y'])
    # def test_zuzhi_04(self):
    #     '组织架构页查询账号'
    #     MyLogin(self.driver).login()
    #     ele = self.driver.find_element_by_xpath('//*[@id="EmployeesMenu2"]/div')
    #     ActionChains(self.driver).move_to_element(ele).perform()   #鼠标定位到员工管理
    #     time.sleep(2)
    #     self.driver.find_element_by_xpath('//*[@x-placement="bottom-start"]/ul/li').click() #获取员工管理下的组织架构并点击
    #     print(self.driver.title)
    #     print(self.driver.current_url)
    #     time.sleep(3)
    #     self.driver.find_element_by_xpath('//*[@type="text"]').send_keys('sg5771')
    #     self.driver.find_element_by_xpath('//*[@class="el-button el-button--primary"]/span').click()
    #     time.sleep(2)
    #     ele_03 = self.driver.find_element_by_xpath('//*[@id="TabEmployeesList"]/div[3]/table/tbody/tr/td[2]/div').text
    #     print(ele_03)
    #     self.assertEqual('sg5771',ele_03)    #断言判断查询出来的数据是否符合预期
    #     time.sleep(2)


if __name__ == '__main__':
    unittest.main()

import unittest
from selenium import webdriver
import os
import time
class login(unittest.TestCase):

    def setUp(self) -> None:
        self.driver = webdriver.Chrome()
        self.driver.get('https://hrmstest.ovivas.cn/Home/Login')
        self.driver.maximize_window()
        # print('打印开始执行每条用例前的时间'+time.strftime(%Y-),time.localtime()
    def tearDown(self) -> None:
        self.driver.quit()
    def test_denglu_01(self):
        '检查文本框中文本内容'
        ele_1 = self.driver.find_element_by_xpath('//*[@placeholder="请输入工号"]').get_attribute('placeholder')  #获取文本框中文本
        print(ele_1)
        self.assertEqual('请输入工号',ele_1)
    def test_denglu_02(self):
        '检查登录是否成功'
        self.driver.find_element_by_xpath('//*[@placeholder="请输入工号"]').send_keys('sg1115')
        self.driver.find_element_by_xpath('//*[@placeholder="请输入密码"]').send_keys('111111a')
        self.driver.find_element_by_xpath('//*[@type="button"]/span').click()
        time.sleep(2)
        ele_2 = self.driver.find_element_by_xpath('//*[@class="myFont"]/span').text  #登录后获取文本内容（非文本输入框）
        print(ele_2)
        self.assertEqual('SG1115',ele_2,'失败')
        # if 'SG11115' == ele:
        #     print('assertion is pass')
        # else:
        #     print('assertion is fail')
        # self.assertIn('S',ele)
        # self.assertNotEqual('SG1115',ele)
        # self.assertTrue('SG1115',self.driver.find_element_by_xpath('//*[@class="myFont"]/span').is_displayed())
    def test_denglu_03(self):
        '检查登录密码错误弹框确认按钮显示'
        self.driver.find_element_by_xpath('//*[@placeholder="请输入工号"]').send_keys('sg1115')
        self.driver.find_element_by_xpath('//*[@placeholder="请输入密码"]').send_keys('错误密码')
        self.driver.find_element_by_xpath('//*[@type="button"]/span').click()
        time.sleep(2)
        ele_3 = self.driver.find_element_by_xpath('//*[@class="el-button el-button--default el-button--small el-button--primary "]/span').text
        print(ele_3)
        self.assertTrue(self.driver.find_element_by_xpath('//*[@class="el-button el-button--default el-button--small el-button--primary "]/span').is_displayed())
if __name__ == '__main__':
    '执行当前测试类中，以test开头的所有测试用例（方法）'
    unittest.main()





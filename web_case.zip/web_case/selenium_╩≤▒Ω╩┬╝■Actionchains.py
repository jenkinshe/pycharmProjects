import time
import webbrowser
from selenium import webdriver
from selenium.webdriver import ActionChains
import unittest

from selenium.webdriver.common.by import By


class test():
    def __init__(self):
        self.driver = webdriver.Chrome()
        self.issuccess = False

    def open(self, url):
        self.driver.get(url)
        self.driver.maximize_window()


    def xpath_test(self, element):
        ene = self.driver.find_element(By.XPATH, element)
        return ene

    def actionschains(self,element: str):
        try:
            en = self.xpath_test(element)
            ActionChains(self.driver).move_to_element(en).perform()
        except Exception as e:
            self.close()
            self.issuccess = False
            print(e)


    def close(self):
        self.driver.close()


abc = test()
abc.open('https://hrmstest.ovivas.cn/Home/Login')
abc.xpath_test('//*[@placeholder="请输入工号"]').send_keys('sg1112')
abc.xpath_test('//*[@type="password"]').send_keys('111111a')
abc.xpath_test('//*[@type="button"]/span').click()
time.sleep(2)

abc.xpath_test('//*[@type="button"]/i').click()
time.sleep(2)
abc.actionschains('//*[@id="EmployeesMenu3"]/div')
time.sleep(2)
abc.xpath_test("//*[@x-placement=‘bottom-start’]/ul/li").click()
time.sleep(5)

abc.close()

